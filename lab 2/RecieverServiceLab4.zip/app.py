from urllib import response
import connexion
from connexion import NoContent
import yaml
import logging
import logging.config
import json
import datetime
import uuid

import requests

MAX_EVENTS= 10
EVENT_FILE= "events.json"

# Your functions here
'''
def json_write(req_string):
    current_time=str(datetime.datetime.now())

    try:
        with open(EVENT_FILE,'r') as json_file:
            data=json.load(json_file)
    except:
        data=[]
    
    print(data)
    event_json = {
        "received_timestamp": current_time,
        "request_data": req_string
    }
    print(event_json)
    data.append(event_json)
    
    if(len(data)>MAX_EVENTS):
        data.pop(0) 
    
    with open(EVENT_FILE,'w') as json_file:
        json.dump(data,json_file,indent=4)
'''
    
with open('app_conf.yml', 'r') as f: 
    app_config = yaml.safe_load(f.read())

with open('log_conf.yml', 'r') as f: 
    log_config = yaml.safe_load(f.read()) 
    logging.config.dictConfig(log_config)

logger = logging.getLogger('basicLogger')

def order_ride_immediately(body):
    trace_id=uuid.uuid4()                            
    logger.info(f'Recieved event \"Ride Order\" with a trace id of {trace_id}')
    headers = { "content-type":"application/json"}
    response = requests.post(app_config["eventstore1"]["url"],
                                json=body, headers=headers)
    logger.info(f"Returned event \"Ride Order\" response (Id: {trace_id}) with status code 201")

    return NoContent,201

def schedule_ride(body):
    #print(body)
    # json_write(request_bio)   
    request_bio = f'User {body["user_id"]} is scheduling a ride to {body["destination"]} between {body["interval_start"]} and {body["interval_end"]} at {body["order_time"]}.'
    trace_id=uuid.uuid4()                            

    logger.info(f'Recieved event \"Schedule Order\" with a trace id of {trace_id}')

    headers = { "content-type":"application/json"}
    response = requests.post(app_config["eventstore2"]["url"],
                                json=body, headers=headers)
    logger.info(f"Returned event \"Schedule Order\" response (Id: {trace_id}) with status code 201")
    return NoContent,201


app = connexion.FlaskApp(__name__,specification_dir='')
app.add_api("BCIT975-RideHail-1.0.0-swagger.yaml",strict_validation=True,validate_responses=True)


if __name__=="__main__":
    app.run(port=8080)