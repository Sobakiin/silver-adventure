import connexion
from connexion import NoContent

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from base import Base
from ride_order import RideOrder
from schedule_ride import RideSchedule
import datetime
import yaml
import logging
import logging.config

# MAX_EVENTS= 10
# EVENT_FILE= "events.json"

# Your functions here

with open('app_conf.yml', 'r') as f:
    app_config = yaml.safe_load(f.read())

with open('log_conf.yml', 'r') as f: 
    log_config = yaml.safe_load(f.read()) 
    logging.config.dictConfig(log_config)

logger = logging.getLogger('basicLogger')

# DB_ENGINE = create_engine("sqlite:///readings.sqlite")
DB_ENGINE = create_engine(f'mysql+pymysql://{app_config["datastore"]["user"]}:{app_config["datastore"]["password"]}@{app_config["datastore"]["hostname"]}:{app_config["datastore"]["port"]}/{app_config["datastore"]["db"]}')
Base.metadata.bind = DB_ENGINE
DB_SESSION = sessionmaker(bind=DB_ENGINE)



def order_ride_immediately(body):
    #print(body)
    # request_bio = f'User {body["user_id"]} requested a {body["max_passenger"]} ride from {body["starting_point"]} to {body["destination"]} at {body["order_time"]}.'
    # json_write(request_bio)

    session = DB_SESSION()

    ro = RideOrder(body['user_id'],
                    body['starting_point'],
                    body['destination'],
                    body['max_passenger'],
                    body['trace_id'])

    session.add(ro)

    session.commit()
    session.close()
    logger.debug(f'Stored event order_ride_immediately request with a trace id of {body["trace_id"]} ')
    return NoContent,201

def schedule_ride(body):
    #print(body)    
    # request_bio = f'User {body["user_id"]} is scheduling a ride to {body["destination"]} between {body["interval_start"]} and {body["interval_end"]} at {body["order_time"]}.'
    # json_write(request_bio)
    session = DB_SESSION()

    rs = RideSchedule(body['user_id'],
                    body['interval_start'],
                    body['interval_end'],
                    body['destination'],
                    body['trace_id'])

    session.add(rs)

    session.commit()
    session.close()
    logger.debug(f'Stored event schedule_ride request with a trace id of {body["trace_id"]} ')
    
    return NoContent,201


app = connexion.FlaskApp(__name__,specification_dir='')
app.add_api("BCIT975-RideHail-1.0.0-swagger.yaml",strict_validation=True,validate_responses=True)


if __name__=="__main__":
    app.run(port=8090)